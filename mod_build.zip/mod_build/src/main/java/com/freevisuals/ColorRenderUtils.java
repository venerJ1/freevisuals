package com.freevisuals;


import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Matrix4f;

public class ColorRenderUtils {
    public static int getRainbowColor(double delay, float speed) {
        long time = System.currentTimeMillis();
        int r = (int) (Math.sin((time * speed) + delay) * 127 + 128);
        int g = (int) (Math.sin((time * speed) + delay + 2.0) * 127 + 128);
        int b = (int) (Math.sin((time * speed) + delay + 4.0) * 127 + 128);
        return (255 << 24) | (r << 16) | (g << 8) | b;
    }

    public static void drawGradientBorder(MatrixStack matrices, int left, int top, int right, int bottom, int color1, int color2) {
        Matrix4f matrix = matrices.peek().getModel();
        float a1 = (float)(color1 >> 24 & 255) / 255.0F; float r1 = (float)(color1 >> 16 & 255) / 255.0F; float g1 = (float)(color1 >> 8 & 255) / 255.0F; float b1 = (float)(color1 & 255) / 255.0F;
        float a2 = (float)(color2 >> 24 & 255) / 255.0F; float r2 = (float)(color2 >> 16 & 255) / 255.0F; float g2 = (float)(color2 >> 8 & 255) / 255.0F; float b2 = (float)(color2 & 255) / 255.0F;
        
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.disableTexture();
        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        
        bb.vertex(matrix, left, top + 1, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, top + 1, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, right, top, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, left, top, 0).color(r1, g1, b1, a1).next();
        bb.vertex(matrix, left, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, bottom, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, right, bottom - 1, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, left, bottom - 1, 0).color(r1, g1, b1, a1).next();
        bb.vertex(matrix, left, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, left + 1, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, left + 1, top, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, left, top, 0).color(r2, g2, b2, a2).next();
        bb.vertex(matrix, right - 1, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, top, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, right - 1, top, 0).color(r2, g2, b2, a2).next();
        
        Tessellator.getInstance().draw(); RenderSystem.enableTexture(); RenderSystem.disableBlend();
    }
}
