package com.freevisuals;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.*;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3f;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FreeVisualsMod implements ClientModInitializer {
    private static KeyBinding openGuiKey;
    public static final List<Module> modules = new ArrayList<>();
    public static final List<JumpCircle> circles = new ArrayList<>();
    public static final List<CustomParticle> particles = new ArrayList<>();
    public static final List<TrailPoint> trailPoints = new ArrayList<>();
    private static boolean wasInAir = false;

    @Override
    public void onInitializeClient() {
        modules.add(new Module("Красивый HUD", true, false));
        modules.add(new Module("Jump Circles", true, true));
        modules.add(new Module("Hit Effect", true, true));
        modules.add(new Module("Elytra Swap", true, true));
        modules.add(new Module("Item Swapper", true, true));
        modules.add(new Module("China Hat", true, true));
        modules.add(new Module("Trails", true, true));

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.freevisuals.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_CONTROL,
                "category.freevisuals"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.interactionManager == null) return;

            if (openGuiKey.wasPressed() && client.currentScreen == null) {
                client.setScreen(new ClickGuiScreen());
            }

            Module jc = getModuleByName("Jump Circles");
            if (jc != null && jc.isEnabled()) {
                if (!client.player.isOnGround() && !client.player.isTouchingWater()) {
                    wasInAir = true;
                } else if (wasInAir && client.player.isOnGround()) {
                    Vec3d landPos = client.player.getPos();
                    float[] color = jc.getRGB();
                    synchronized (circles) {
                        circles.add(new JumpCircle(new Vec3d(landPos.x, landPos.y + 0.02, landPos.z), color[0], color[1], color[2]));
                    }
                    wasInAir = false;
                }
            }

            Module tr = getModuleByName("Trails");
            if (tr != null && tr.isEnabled() && (client.player.getX() != client.player.prevX || client.player.getZ() != client.player.prevZ)) {
                synchronized (trailPoints) {
                    trailPoints.add(new TrailPoint(client.player.getPos().add(0, 0.5, 0)));
                }
            }
            synchronized (trailPoints) {
                List<TrailPoint> toRemove = new ArrayList<>();
                for (TrailPoint p : trailPoints) { if (p.update()) toRemove.add(p); }
                trailPoints.removeAll(toRemove);
            }

            if (client.currentScreen != null) return;

            Module es = getModuleByName("Elytra Swap");
            if (es != null && es.isEnabled() && !es.listeningForBind) {
                if (InputUtil.isKeyPressed(client.getWindow().getHandle(), es.bindKey)) {
                    int syncId = client.player.currentScreenHandler.syncId;
                    ItemStack chestItem = client.player.getInventory().getArmorStack(2);
                    int targetSlot = -1;

                    if (chestItem.getItem() == Items.NETHERITE_CHESTPLATE || chestItem.getItem() == Items.DIAMOND_CHESTPLATE) {
                        targetSlot = findItem(client.player, Items.ELYTRA);
                    } else if (chestItem.getItem() == Items.ELYTRA) {
                        targetSlot = findItem(client.player, Items.NETHERITE_CHESTPLATE);
                        if (targetSlot == -1) targetSlot = findItem(client.player, Items.DIAMOND_CHESTPLATE);
                    }

                    if (targetSlot != -1) {
                        client.interactionManager.clickSlot(syncId, targetSlot, 0, SlotActionType.QUICK_MOVE, client.player);
                    }
                }
            }

            Module is = getModuleByName("Item Swapper");
            if (is != null && is.isEnabled() && !is.listeningForBind) {
                if (InputUtil.isKeyPressed(client.getWindow().getHandle(), is.swapperKey)) {
                    int syncId = client.player.currentScreenHandler.syncId;
                    if (is.swapperMode == 0) {
                        ItemStack mainHand = client.player.getMainHandStack();
                        int targetSlot = -1;
                        if (mainHand.getItem() == Items.GOLDEN_APPLE) targetSlot = findItem(client.player, Items.ENCHANTED_GOLDEN_APPLE);
                        else if (mainHand.getItem() == Items.ENCHANTED_GOLDEN_APPLE) targetSlot = findItem(client.player, Items.GOLDEN_APPLE);

                        if (targetSlot != -1) {
                            client.interactionManager.clickSlot(syncId, targetSlot, client.player.getInventory().selectedSlot + 36, SlotActionType.SWAP, client.player);
                        }
                    } else {
                        ItemStack offHand = client.player.getOffHandStack();
                        Item targetItem = (is.swapperMode == 1) ? Items.TOTEM_OF_UNDYING : Items.SHIELD;
                        if (offHand.getItem() != targetItem) {
                            int targetSlot = findItem(client.player, targetItem);
                            if (targetSlot != -1) {
                                client.interactionManager.clickSlot(syncId, targetSlot, 40, SlotActionType.SWAP, client.player);
                            }
                        }
                    }
                }
            }
        });
    }

    private static int findItem(net.minecraft.client.network.ClientPlayerEntity player, Item item) {
        for (int i = 9; i < 45; i++) {
            ItemStack stack = player.currentScreenHandler.getSlot(i).getStack();
            if (!stack.isEmpty() && stack.getItem() == item) return i;
        }
        return -1;
    }

    public static Module getModuleByName(String name) {
        for (Module m : modules) { if (m.name.equalsIgnoreCase(name)) return m; }
        return null;
    }
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.interactionManager == null) return;

            if (openGuiKey.wasPressed() && client.currentScreen == null) {
                client.setScreen(new ClickGuiScreen());
            }

            Module jc = getModuleByName("Jump Circles");
            if (jc != null && jc.isEnabled()) {
                if (!client.player.isOnGround() && !client.player.isTouchingWater()) {
                    wasInAir = true;
                } else if (wasInAir && client.player.isOnGround()) {
                    Vec3d landPos = client.player.getPos();
                    float[] color = jc.getRGB();
                    synchronized (circles) {
                        circles.add(new JumpCircle(new Vec3d(landPos.x, landPos.y + 0.02, landPos.z), color, color, color));
                    }
                    wasInAir = false;
                }
            }

            Module tr = getModuleByName("Trails");
            if (tr != null && tr.isEnabled() && (client.player.getX() != client.player.prevX || client.player.getZ() != client.player.prevZ)) {
                synchronized (trailPoints) {
                    trailPoints.add(new TrailPoint(client.player.getPos().add(0, 0.5, 0)));
                }
            }
            synchronized (trailPoints) {
                List<TrailPoint> toRemove = new ArrayList<>();
                for (TrailPoint p : trailPoints) { if (p.update()) toRemove.add(p); }
                trailPoints.removeAll(toRemove);
            }

            if (client.currentScreen != null) return;

            Module es = getModuleByName("Elytra Swap");
            if (es != null && es.isEnabled() && !es.listeningForBind) {
                if (InputUtil.isKeyPressed(client.getWindow().getHandle(), es.bindKey)) {
                    int syncId = client.player.currentScreenHandler.syncId;
                    ItemStack chestItem = client.player.getInventory().getArmorStack(2);
                    int targetSlot = -1;

                    if (chestItem.getItem() == Items.NETHERITE_CHESTPLATE || chestItem.getItem() == Items.DIAMOND_CHESTPLATE) {
                        targetSlot = findItem(client.player, Items.ELYTRA);
                    } else if (chestItem.getItem() == Items.ELYTRA) {
                        targetSlot = findItem(client.player, Items.NETHERITE_CHESTPLATE);
                        if (targetSlot == -1) targetSlot = findItem(client.player, Items.DIAMOND_CHESTPLATE);
                    }

                    if (targetSlot != -1) {
                        client.interactionManager.clickSlot(syncId, targetSlot, 0, SlotActionType.QUICK_MOVE, client.player);
                    }
                }
            }

            Module is = getModuleByName("Item Swapper");
            if (is != null && is.isEnabled() && !is.listeningForBind) {
                if (InputUtil.isKeyPressed(client.getWindow().getHandle(), is.swapperKey)) {
                    int syncId = client.player.currentScreenHandler.syncId;
                    if (is.swapperMode == 0) {
                        ItemStack mainHand = client.player.getMainHandStack();
                        int targetSlot = -1;
                        if (mainHand.getItem() == Items.GOLDEN_APPLE) targetSlot = findItem(client.player, Items.ENCHANTED_GOLDEN_APPLE);
                        else if (mainHand.getItem() == Items.ENCHANTED_GOLDEN_APPLE) targetSlot = findItem(client.player, Items.GOLDEN_APPLE);

                        if (targetSlot != -1) {
                            client.interactionManager.clickSlot(syncId, targetSlot, client.player.getInventory().selectedSlot + 36, SlotActionType.SWAP, client.player);
                        }
                    } else {
                        ItemStack offHand = client.player.getOffHandStack();
                        Item targetItem = (is.swapperMode == 1) ? Items.TOTEM_OF_UNDYING : Items.SHIELD;
                        if (offHand.getItem() != targetItem) {
                            int targetSlot = findItem(client.player, targetItem);
                            if (targetSlot != -1) {
                                client.interactionManager.clickSlot(syncId, targetSlot, 40, SlotActionType.SWAP, client.player);
                            }
                        }
                    }
                }
            }
        });
    }

    private static int findItem(net.minecraft.client.network.ClientPlayerEntity player, Item item) {
        for (int i = 9; i < 45; i++) {
            ItemStack stack = player.currentScreenHandler.getSlot(i).getStack();
            if (!stack.isEmpty() && stack.getItem() == item) return i;
        }
        return -1;
    }

    public static Module getModuleByName(String name) {
        for (Module m : modules) { if (m.name.equalsIgnoreCase(name)) return m; }
        return null;
    }
    public static void onAttack(Entity target) {
        Module mod = getModuleByName("Hit Effect");
        if (mod == null || !mod.isEnabled() || !(target instanceof LivingEntity)) return;
        synchronized (particles) {
            for (int i = 0; i < 12; i++) {
                particles.add(new CustomParticle(target.getX(), target.getEyeY() - 0.3, target.getZ(), mod.colorMode, mod.shapeMode));
            }
        }
    }

    public static class Module {
        public final String name;
        private boolean enabled;
        public final boolean hasSettings;
        public int colorMode = 0;
        public int shapeMode = 0;
        public int hatShape = 0;
        public int hatSize = 0;
        public int bindKey = GLFW.GLFW_KEY_G;
        public int swapperKey = GLFW.GLFW_KEY_X;
        public int swapperMode = 0;
        public boolean listeningForBind = false;

        public Module(String name, boolean defaultEnabled, boolean hasSettings) {
            this.name = name; this.enabled = defaultEnabled; this.hasSettings = hasSettings;
        }
        public boolean isEnabled() { return enabled; }
        public void toggle() { this.enabled = !this.enabled; }
        public String getColorName() {
            if (colorMode == 1) return "§cКрасный"; if (colorMode == 2) return "§aЗеленый"; if (colorMode == 3) return "§dРадуга"; return "§bБирюзовый";
        }
        public String getShapeName() {
            if (shapeMode == 1) return "§dСердечки"; if (shapeMode == 2) return "§eКрестики"; return "§bЗвёздочки";
        }
        public int getHexColor() {
            if (colorMode == 1) return 0xFFFF0000; if (colorMode == 2) return 0xFF00FF00;
            if (colorMode == 3) {
                long t = System.currentTimeMillis();
                int r = (int) (Math.sin(t * 0.003) * 127 + 128); int g = (int) (Math.sin(t * 0.003 + 2) * 127 + 128); int b = (int) (Math.sin(t * 0.003 + 4) * 127 + 128);
                return (255 << 24) | (r << 16) | (g << 8) | b;
            }
            return 0xFF00BFFF;
        }
        public float[] getRGB() {
            int hex = getHexColor();
            return new float[]{((hex >> 16) & 255) / 255f, ((hex >> 8) & 255) / 255f, (hex & 255) / 255f};
        }
    }

    public static class JumpCircle {
        public final Vec3d position; public float radius = 0.1f; public float alpha = 1.0f;
        public final float[] r, g, b;
        public JumpCircle(Vec3d pos, float[] r, float[] g, float[] b) { this.position = pos; this.r = r; this.g = g; this.b = b; }
        public boolean update() { this.radius += 0.05f; this.alpha -= 0.04f; return this.alpha <= 0.0f || this.radius >= 1.2f; }
    }

    public static class CustomParticle {
        double x, y, z, motX, motY, motZ; float r, g, b, alpha = 1.0f; float size = 0.08f; final int shapeMode;
        public CustomParticle(double x, double y, double z, int cMode, int sMode) {
            Random rand = new Random(); this.shapeMode = sMode;
            this.x = x + (rand.nextDouble() - 0.5) * 0.2; this.y = y + (rand.nextDouble() - 0.5) * 0.2; this.z = z + (rand.nextDouble() - 0.5) * 0.2;
            this.motX = (rand.nextDouble() - 0.5) * 0.15; this.motY = (rand.nextDouble() - 0.3) * 0.15 + 0.05; this.motZ = (rand.nextDouble() - 0.5) * 0.15;
            this.r = 0f; this.g = 0.7f; this.b = 1f;
            if (cMode == 1) { this.r = 1f; this.g = 0f; this.b = 0f; } else if (cMode == 2) { this.r = 0f; this.g = 1f; this.b = 0f; }
            else if (cMode == 3) {
                long t = System.currentTimeMillis() + rand.nextInt(1000);
                this.r = (float)(Math.sin(t*0.005)*0.5+0.5); this.g = (float)(Math.sin(t*0.005+2)*0.5+0.5); this.b = (float)(Math.sin(t*0.005+4)*0.5+0.5);
            }
        }
        public void update() {
            this.x += motX; this.y += motY; this.z += motZ; this.motX *= 0.92; this.motY = (this.motY * 0.92) - 0.005; this.motZ *= 0.92; this.alpha -= 0.05f;
        }
    }

    public static class TrailPoint {
        public final Vec3d position; public float alpha = 1.0f;
        public TrailPoint(Vec3d pos) { this.position = pos; }
        public boolean update() { this.alpha -= 0.05f; return this.alpha <= 0.0f; }
    }
    public static class ClickGuiScreen extends Screen {
        private Module selectedModule = null;
        public ClickGuiScreen() { super(new LiteralText("Menu")); }

        @Override
        public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
            this.renderBackground(matrices);
            int w = 250; int h = 180; int x = (this.width - w) / 2; int y = (this.height - h) / 2;
            long time = System.currentTimeMillis();
            int g1 = (255<<24)|((int)(Math.sin(time*0.002)*127+128)<<16)|((int)(Math.sin(time*0.002+2)*127+128)<<8)|(int)(Math.sin(time*0.002+4)*127+128);
            int g2 = (255<<24)|((int)(Math.sin(time*0.002+1.5)*127+128)<<16)|((int)(Math.sin(time*0.002+3.5)*127+128)<<8)|(int)(Math.sin(time*0.002+5.5)*127+128);

            fill(matrices, x, y, x + w, y + h, 0xFF141414);
            drawBorder(matrices, x, y, x + w, y + h, g1, g2);
            this.textRenderer.drawWithShadow(matrices, "FREE VISUALS  |  СПИСОК МОДОВ", x + 12, y + 10, 0xFF00BFFF);

            int mY = y + 32;
            for (Module m : modules) {
                fill(matrices, x + 10, mY, x + w - 10, mY + 22, 0xFF222222);
                int bColor = m.isEnabled() ? m.getHexColor() : 0xFF444444;
                drawBorder(matrices, x + 10, mY, x + w - 10, mY + 22, bColor, bColor);
                this.textRenderer.drawWithShadow(matrices, m.name, x + 20, mY + 7, 0xFFFFFFFF);
                this.textRenderer.drawWithShadow(matrices, m.isEnabled() ? "[ ВКЛ ]" : "[ ВЫКЛ ]", x + w - 95, mY + 7, m.isEnabled() ? 0xFF00FF00 : 0xFFFF0000);
                if (m.hasSettings) this.textRenderer.drawWithShadow(matrices, "[⚙]", x + w - 35, mY + 7, selectedModule == m ? m.getHexColor() : 0xFFAAAAAA);
                mY += 26;
            }

            if (selectedModule != null) {
                int sX = x + w + 8; int sW = 130; int mc = selectedModule.getHexColor();
                fill(matrices, sX, y, sX + sW, y + h, 0xFF111111);
                drawBorder(matrices, sX, y, sX + sW, y + h, mc, 0xFF000000);
                this.textRenderer.drawWithShadow(matrices, "НАСТРОЙКИ", sX + 10, y + 10, mc);

                if (selectedModule.name.equals("Elytra Swap") || selectedModule.name.equals("Item Swapper")) {
                    fill(matrices, sX + 10, y + 45, sX + sW - 10, y + 65, 0xFF1F1F1F);
                    this.textRenderer.drawWithShadow(matrices, "Кнопка:", sX + 14, y + 51, 0xFFFFFFFF);
                    String key = selectedModule.listeningForBind ? "Жмите" : (selectedModule.name.equals("Item Swapper") ? GLFW.glfwGetKeyName(selectedModule.swapperKey, 0) : GLFW.glfwGetKeyName(selectedModule.bindKey, 0));
                    this.textRenderer.drawWithShadow(matrices, key == null ? "Кл" : key.toUpperCase(), sX + 65, y + 51, mc);

                    if (selectedModule.name.equals("Item Swapper")) {
                        fill(matrices, sX + 10, y + 75, sX + sW - 10, y + 105, 0xFF1F1F1F);
                        this.textRenderer.drawWithShadow(matrices, "Режим:", sX + 14, y + 81, 0xFFFFFFFF);
                        String sMode = selectedModule.swapperMode == 1 ? "Тотем" : (selectedModule.swapperMode == 2 ? "Щит" : "Талисманы");
                        this.textRenderer.drawWithShadow(matrices, sMode, sX + 14, y + 93, 0xFFBBBBBB);
                    }
                } else {
                    fill(matrices, sX + 10, y + 45, sX + sW - 10, y + 65, 0xFF1F1F1F);
                    this.textRenderer.drawWithShadow(matrices, "Цвет:", sX + 14, y + 51, 0xFFFFFFFF);
                    this.textRenderer.drawWithShadow(matrices, selectedModule.getColorName(), sX + 52, y + 51, 0xFFFFFFFF);

                    if (selectedModule.name.equals("Hit Effect")) {
                        fill(matrices, sX + 10, y + 72, sX + sW - 10, y + 92, 0xFF1F1F1F);
                        this.textRenderer.drawWithShadow(matrices, "Форма:", sX + 14, y + 78, 0xFFFFFFFF);
                        this.textRenderer.drawWithShadow(matrices, selectedModule.getShapeName(), sX + 58, y + 78, 0xFFFFFFFF);
                    }
                    if (selectedModule.name.equals("China Hat") || selectedModule.name.equals("Trails")) {
                        fill(matrices, sX + 10, y + 72, sX + sW - 10, y + 92, 0xFF1F1F1F);
                        this.textRenderer.drawWithShadow(matrices, "Форма:", sX + 14, y + 78, 0xFFFFFFFF);
                        String fName = selectedModule.name.equals("China Hat") ? (selectedModule.hatShape == 1 ? "Линии" : "Сплошь") : "Лента";
                        this.textRenderer.drawWithShadow(matrices, fName, sX + 58, y + 78, 0xFFFFFFFF);

                        if (selectedModule.name.equals("China Hat")) {
                            fill(matrices, sX + 10, y + 99, sX + sW - 10, y + 119, 0xFF1F1F1F);
                            this.textRenderer.drawWithShadow(matrices, "Размер:", sX + 14, y + 105, 0xFFFFFFFF);
                            String sSize = selectedModule.hatSize == 1 ? "Биг" : (selectedModule.hatSize == 2 ? "Смол" : "Норм");
                            this.textRenderer.drawWithShadow(matrices, sSize, sX + 62, y + 105, 0xFFFFFFFF);
                        }
                    }
                }
            }
            super.render(matrices, mouseX, mouseY, delta);
        }
        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) {
                int w = 250; int x = (this.width - w) / 2; int y = (this.height - 180) / 2; int mY = y + 32;
                for (Module m : modules) {
                    if (mouseX >= x + 10 && mouseX <= x + w - 40 && mouseY >= mY && mouseY <= mY + 22) {
                        m.toggle(); this.client.player.playSound(SoundEvents.UI_BUTTON_CLICK, 1f, 1f); return true;
                    }
                    if (m.hasSettings && mouseX >= x + w - 39 && mouseX <= x + w - 10 && mouseY >= mY && mouseY <= mY + 22) {
                        selectedModule = (selectedModule == m) ? null : m; this.client.player.playSound(SoundEvents.UI_BUTTON_CLICK, 1f, 1f); return true;
                    }
                    mY += 26;
                }
                if (selectedModule != null) {
                    int sX = x + w + 8;
                    if (mouseX >= sX + 10 && mouseX <= sX + 120 && mouseY >= y + 45 && mouseY <= y + 65) {
                        if (selectedModule.name.equals("Elytra Swap") || selectedModule.name.equals("Item Swapper")) selectedModule.listeningForBind = true;
                        else selectedModule.colorMode = (selectedModule.colorMode + 1) % 4;
                        this.client.player.playSound(SoundEvents.UI_BUTTON_CLICK, 1f, 1f); return true;
                    }
                    if (mouseX >= sX + 10 && mouseX <= sX + 120 && mouseY >= y + 72 && mouseY <= y + 92) {
                        if (selectedModule.name.equals("Hit Effect")) selectedModule.shapeMode = (selectedModule.shapeMode + 1) % 3;
                        if (selectedModule.name.equals("China Hat")) selectedModule.hatShape = (selectedModule.hatShape + 1) % 2;
                        if (selectedModule.name.equals("Item Swapper")) selectedModule.swapperMode = (selectedModule.swapperMode + 1) % 3;
                        this.client.player.playSound(SoundEvents.UI_BUTTON_CLICK, 1f, 1f); return true;
                    }
                    if (selectedModule.name.equals("China Hat") && mouseX >= sX + 10 && mouseX <= sX + 120 && mouseY >= y + 99 && mouseY <= y + 119) {
                        selectedModule.hatSize = (selectedModule.hatSize + 1) % 3; this.client.player.playSound(SoundEvents.UI_BUTTON_CLICK, 1f, 1f); return true;
                    }
                }
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
            if (selectedModule != null && selectedModule.listeningForBind) {
                if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                    if (selectedModule.name.equals("Item Swapper")) selectedModule.swapperKey = keyCode;
                    else selectedModule.bindKey = keyCode;
                }
                selectedModule.listeningForBind = false;
                this.client.player.playSound(SoundEvents.UI_BUTTON_CLICK, 1f, 1f); return true;
            }
            return super.keyPressed(keyCode, scanCode, modifiers);
        }

        private void drawBorder(MatrixStack matrices, int left, int top, int right, int bottom, int color1, int color2) {
            Matrix4f matrix = matrices.peek().getModel();
            float a1 = (color1 >> 24 & 255) / 255f; float r1 = (color1 >> 16 & 255) / 255f; float g1 = (color1 >> 8 & 255) / 255f; float b1 = (color1 & 255) / 255f;
            float a2 = (color2 >> 24 & 255) / 255f; float r2 = (color2 >> 16 & 255) / 255f; float g2 = (color2 >> 8 & 255) / 255f; float b2 = (color2 & 255) / 255f;
            RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc(); RenderSystem.disableTexture();
            BufferBuilder bb = Tessellator.getInstance().getBuffer();
            bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            bb.vertex(matrix, left, top + 1, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, top + 1, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, right, top, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, left, top, 0).color(r1, g1, b1, a1).next();
            bb.vertex(matrix, left, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, bottom, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, right, bottom - 1, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, left, bottom - 1, 0).color(r1, g1, b1, a1).next();
            bb.vertex(matrix, left, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, left + 1, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, left + 1, top, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, left, top, 0).color(r2, g2, b2, a2).next();
            bb.vertex(matrix, right - 1, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, bottom, 0).color(r1, g1, b1, a1).next(); bb.vertex(matrix, right, top, 0).color(r2, g2, b2, a2).next(); bb.vertex(matrix, right - 1, top, 0).color(r2, g2, b2, a2).next();
            Tessellator.getInstance().draw(); RenderSystem.enableTexture(); RenderSystem.disableBlend();
        }
        @Override public boolean isPauseScreen() { return false; }
    }
}

