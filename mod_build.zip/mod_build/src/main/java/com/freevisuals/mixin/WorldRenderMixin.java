package com.freevisuals.mixin;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Matrix4f;
import org.spongepowered.mixin.mixin.Mixin;
import org.spongepowered.mixin.mixin.injection.At;
import org.spongepowered.mixin.mixin.injection.Inject;
import org.spongepowered.mixin.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WorldRenderMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderWorld(MatrixStack m, float td, long lt, boolean rbo, net.minecraft.client.render.Camera c, net.minecraft.client.render.GameRenderer gr, net.minecraft.client.render.LightmapTextureManager ltm, Matrix4f m4f, CallbackInfo ci) {}
}
