package com.freevisuals.mixin;

import com.freevisuals.FreeVisualsMod;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import org.spongepowered.mixin.mixin.Mixin;
import org.spongepowered.mixin.mixin.injection.At;
import org.spongepowered.mixin.mixin.injection.Inject;
import org.spongepowered.mixin.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class AttackEntityMixin {
    @Inject(method = "attack", at = @At("HEAD"))
    private void onAttack(Entity target, CallbackInfo ci) {
        FreeVisualsMod.onAttack(target);
    }
}
