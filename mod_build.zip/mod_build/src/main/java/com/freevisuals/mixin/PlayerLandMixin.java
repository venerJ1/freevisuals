package com.freevisuals.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.mixin.mixin.Mixin;
import org.spongepowered.mixin.mixin.injection.At;
import org.spongepowered.mixin.mixin.injection.Inject;
import org.spongepowered.mixin.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class PlayerLandMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {}
}
