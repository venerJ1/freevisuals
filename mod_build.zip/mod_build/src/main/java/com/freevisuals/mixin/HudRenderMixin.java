package com.freevisuals.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.mixin.mixin.Mixin;
import org.spongepowered.mixin.mixin.injection.At;
import org.spongepowered.mixin.mixin.injection.Inject;
import org.spongepowered.mixin.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class HudRenderMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(MatrixStack m, float d, CallbackInfo ci) {}
}
